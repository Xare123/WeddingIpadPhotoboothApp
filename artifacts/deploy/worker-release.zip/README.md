# Worker deployment handoff

Run `npm run build:api` from the repository root to reproduce `worker.mjs` and its SHA-256 manifest. This builds a local artifact only; it does not provision, deploy, publish photos or send SMS. `worker.mjs` is an ES module with a default `fetch` export. Importable module syntax is checked locally.

The coordinating task owns connected Cloudflare writes. Deploy this as a new dedicated gallery Worker with these bindings, after checking the manifest hash and tests:

The coordinator's isolated Worker is named **`wedding-photobooth`**. This artifact accepts V1/V2 legacy recipes plus the new V3 generated-art exact-square contract. Exact source and bundle hashes are in `manifest.json`. **Deploy V3 backend support before installing an app that publishes V3 keepsakes.** This executor has not deployed it and has not inspected current live settings. Preserve existing encrypted secrets through `keep_bindings: ["secret_text"]`, and preserve the actual production pairing/SMS mode, TTL and rate-limit settings rather than blindly replacing them with example values. No secret value belongs in a public artifact. The manifest's `deployed:false` describes the local build only. Existing galleries and immutable recipe acknowledgements remain supported.

- Existing private R2 bucket `gizelleandrami-photoboothphotos` bound as `PHOTOS`; do not create a duplicate or enable public bucket access.
- Variables `MODE=production`, `SMS_MODE=mock`, `PUBLIC_ORIGIN=https://photos.gizelleandrami.com`, `LINK_TTL_SECONDS=604800` (recommended seven days, configurable from 60 seconds through 30 days). Expiry closes guest access and does not delete originals.
- All eight native `ratelimit` bindings in the manifest. The example namespace IDs `1001`–`1008` must be reviewed and changed if they overlap other account Workers. Missing/invalid/erroring production bindings return 503 before R2 access; quota denials return 429. Limits are approximate per Cloudflare POP and cannot impose a hard worldwide spending/storage cap. Confirm the existing account plan supports these bindings; do not upgrade a plan or provision paid infrastructure without approval.
- Securely entered, distinct `DEVICE_TOKEN` and `LINK_SIGNING_KEY`, each at least 32 bytes and 12 distinct characters. No values are generated, printed or included here.
- Existing backend-only `TEXTBELT_API_KEY`, optional for QR-only operation. Preserve it without retrieving its value. Live/test approval flags remain disabled in the example; paid credits and a submitted domain form do not establish eligibility. This executor sends zero real or remote test messages; the coordinator owns the owner's approved test-send limit.
- A separate Worker custom domain on `photos.gizelleandrami.com`, with `workers.dev`/preview URLs disabled. Apply the manifest's explicit disabled observability/log/trace/persistence settings, `logpush:false`, and empty tail consumers. Query-string redaction alone does not protect a gallery token in the URL path. Verify account-level logging and integrations separately. If a connector cannot apply necessary controls, stop and report that limitation instead of dropping them.

`manifest.json` derives variables, R2 and rate-limit bindings, and privacy metadata directly from the production example so they cannot silently drift. `deploymentMetadata` is the ES-module upload metadata; secret values are intentionally absent and must be entered through the approved secure Cloudflare route. No static-assets binding is required: the gallery HTML/CSS and guest keepsake client source are embedded in the Worker bundle; original images and the three generated background artwork objects are read privately from R2. Domain attachment is a separate operation and is not included as an active route here.

Website/DNS edits needed for this flow are authorized, but preserve the apex, `www`, the existing `gizelleandrami` Worker and all wedding-site content. The production EXAMPLE config has no active account/zone/routes or secrets, so it cannot accidentally change those records by running this build.

Before claiming live readiness, verify the following with synthetic images and mock SMS only. A healthy `/health` response checks configuration, not R2 read/write authorization:

1. Inspect the live Worker bindings, canonical domain, logging/trace settings, private bucket settings and budgets; confirm both distinct secrets were supplied securely after approval.
2. Request health, then confirm an unauthenticated upload returns 401 and readiness before uploading returns 409.
3. With the secure booth bearer, PUT four selected synthetic JPEGs, their corresponding untouched originals and a separately rendered keepsake to `/v1/sessions/<new session UUID>/photos/<new photo UUID>`. Original/selected identities may overlap; upload each distinct ID once. Repeat each PUT and expect 201 then 200 with stable IDs. Do not use real guest photos.
4. POST the exact four-photo descriptor from [the API contract](../../docs/API.md) to `/v1/sessions/<session UUID>/ready`: ordered `photoIds`, corresponding `originalPhotoIds`, and `composite` containing its distinct `photoId`, `layout`, `theme` and `version`. New `wedding-template-v2` descriptors also require `gridAspect` (`portrait` or `square`), including for strips. Old `wedding-template-v1` descriptors retain exactly their old four fields and geometry; do not add or infer aspect for them. A missing required asset must prevent readiness. Confirm the response echoes every field exactly, the URL uses the approved HTTPS origin, and expiry is in the future. Changing order, role, version or aspect must return 409; exact replay retains URL/expiry. Separately preserve the documented legacy five-photo descriptor behavior.
5. Open that session URL and download the keepsake, selected photos and untouched originals. Compare downloaded bytes/hash to the uploaded assets. Confirm a wrong token and any photo outside that manifest are denied, and no listing/raw-bucket route is exposed. Other retained takes must never appear incidentally.
6. If testing sharing, first require health reports `sms:mock`, use a reserved fictional number, verify missing consent is rejected and the consented response says mocked. Do not exercise a real sender.
7. DELETE `/v1/sessions/<session UUID>/gallery` and verify both page and download return 410. The synthetic private originals remain for explicit owner cleanup; revocation/expiry is not deletion.

Local Miniflare/browser success does not establish live R2, rate-limit enforcement at the edge, DNS, logging privacy or actual-iPad readiness. Scan the live ready URL from a second phone on cellular data after deployment; browser decoding alone is insufficient.

Private iPad setup uses only the two approved booth credentials. See [the precise two-key pairing contract](../../docs/PRIVATE_PROVISIONING.md): explicitly enable pairing, issue a short-lived code using existing booth authorization, privately scan its raw code through host controls, and consume atomically before Keychain acknowledgment. Do not mint the five-minute code while the owner is asleep or before installation is ready. Live pairing and storage checks remain coordinator/owner actions.

Do not use the local HTTP smoke script unchanged against production: it intentionally targets loopback and contains known local-only development values. Enter the production device token only through a secure approved route and the iPad's OS-authenticated host settings.

## Guest keepsake artwork update (not deployed)

This website-only update requires **both the new Worker code and three private artwork object uploads**. Building a ZIP or deploying code alone does not establish readiness. `npm run build:api` creates `guest-artwork-v3/manifest.json` and three exact-byte PNGs alongside `worker.mjs`. The manifest records each source path, SHA-256, byte count, `image/png` content type, and fixed destination:

- `guest-artwork-v3/classic.png` → `system/keepsake-art/v3/classic.png`
- `guest-artwork-v3/botanical.png` → `system/keepsake-art/v3/botanical.png`
- `guest-artwork-v3/coastal.png` → `system/keepsake-art/v3/coastal.png`

Upload only these generated, text-free design assets to the **existing private** `gizelleandrami-photoboothphotos` bucket. No new bucket, public bucket access, credentials or provisioning is required. Preserve existing object data and verify all three uploaded byte hashes against the manifest. The Worker must authorize guest artwork access through the valid session/capability route; fixed R2 keys are not public URLs. This package contains no real guest images, phone numbers or secrets.

The coordinator owns deployment and any permitted live verification. This executor has performed **no deployment, object upload, origin probe, SMS request or production setting change**. Preserve actual production variables, encrypted secret bindings, pairing configuration, SMS mode, link TTL and rate-limit settings. `manifest.json` derives example defaults for review, **not** instructions to overwrite current live settings.

After the final tested source is frozen, rebuild with `npm run build:api`, then from `artifacts/deploy` create the release archive with `zip -r worker-release.zip worker.mjs manifest.json README.md guest-artwork-v3`. Remove an obsolete local ZIP before creating a replacement so old entries cannot remain. The coordinator must review final source/bundle/artwork hashes and tests before updating production. Do not treat this document or `deployed:false` as evidence of live inspection.
